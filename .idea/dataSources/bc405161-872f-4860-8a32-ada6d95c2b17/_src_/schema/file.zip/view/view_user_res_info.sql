CREATE VIEW view_user_res_info AS
  SELECT
    `file`.`user_res_info`.`id`                AS `id`,
    `file`.`user_res_info`.`textbookVersionId` AS `textbookVersionId`,
    `file`.`user_res_info`.`gradeId`           AS `gradeId`,
    `file`.`user_res_info`.`courseId`          AS `courseId`,
    `file`.`user_res_info`.`title`             AS `title`,
    `file`.`user_res_info`.`summary`           AS `summary`,
    `file`.`user_res_info`.`content`           AS `content`,
    `file`.`user_res_info`.`fileId`            AS `fileId`,
    `file`.`upload_file_info`.`name`           AS `name`,
    `file`.`upload_file_info`.`path`           AS `path`,
    `file`.`upload_file_info`.`size`           AS `size`,
    `file`.`upload_file_info`.`ext`            AS `ext`,
    `file`.`upload_file_info`.`ext`            AS `thumbnail`,
    `file`.`user_res_info`.`isPublic`          AS `isPublic`,
    `file`.`user_res_info`.`isDel`             AS `isDel`,
    `file`.`user_res_info`.`createUserId`      AS `createUserId`,
    `master`.`user_base_info`.`realName`       AS `createUserRealName`,
    `file`.`user_res_info`.`createTime`        AS `createTime`,
    `file`.`user_res_info`.`updateTime`        AS `updateTime`
  FROM ((`file`.`user_res_info`
    JOIN `file`.`upload_file_info`) JOIN `master`.`user_base_info`)
  WHERE ((`file`.`user_res_info`.`fileId` = `file`.`upload_file_info`.`id`) AND
         (`file`.`user_res_info`.`createUserId` = `master`.`user_base_info`.`userId`));
