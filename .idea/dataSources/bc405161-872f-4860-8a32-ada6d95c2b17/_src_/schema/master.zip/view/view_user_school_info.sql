CREATE VIEW view_user_school_info AS
  SELECT
    `master`.`user_school_info`.`userId`   AS `userId`,
    `master`.`user_base_info`.`realName`   AS `realName`,
    `master`.`user_school_info`.`schoolId` AS `schoolId`,
    `master`.`school_info`.`name`          AS `schoolName`,
    `master`.`school_info`.`addrCountyId`  AS `addrCountyId`,
    `area`.`area_county`.`name`            AS `addrCountyName`,
    `area`.`area_city`.`id`                AS `addrCityId`,
    `area`.`area_city`.`name`              AS `addrCityName`,
    `area`.`area_province`.`id`            AS `addrProvinceId`,
    `area`.`area_province`.`name`          AS `addrProvinceName`
  FROM (((((`master`.`user_school_info`
    JOIN `master`.`school_info`) JOIN `master`.`user_base_info`) JOIN `area`.`area_county`) JOIN
    `area`.`area_city`) JOIN `area`.`area_province`)
  WHERE ((`master`.`user_school_info`.`schoolId` = `master`.`school_info`.`id`) AND
         (`master`.`user_school_info`.`userId` = `master`.`user_base_info`.`userId`) AND
         (`master`.`school_info`.`addrCountyId` = `area`.`area_county`.`id`) AND
         (`area`.`area_county`.`fatherId` = `area`.`area_city`.`id`) AND
         (`area`.`area_city`.`fatherId` = `area`.`area_province`.`id`));
