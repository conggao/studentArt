CREATE VIEW view_area_info AS
  SELECT
    `county`.`id`     AS `countyId`,
    `county`.`name`   AS `countyName`,
    `province`.`name` AS `provinceName`,
    `city`.`name`     AS `cityName`
  FROM ((`area`.`area_county` `county`
    JOIN `area`.`area_province` `province`) JOIN `area`.`area_city` `city`
      ON (((`county`.`fatherId` = `city`.`id`) AND (`city`.`fatherId` = `province`.`id`))));
