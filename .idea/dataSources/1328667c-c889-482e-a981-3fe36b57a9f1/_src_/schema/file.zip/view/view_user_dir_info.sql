CREATE VIEW view_user_dir_info AS
  SELECT
    `d`.`id`         AS `id`,
    `d`.`parentId`   AS `parentId`,
    `d`.`name`       AS `name`,
    `d`.`schoolId`   AS `schoolId`,
    `d`.`createTime` AS `createTime`,
    `d`.`isDel`      AS `isDel`,
    `u`.`userName`   AS `createUserName`,
    `u`.`userId`     AS `createUserId`
  FROM (`file`.`dir_info` `d`
    JOIN `master`.`user_base_info` `u` ON ((`d`.`createUserId` = `u`.`userId`)));
