CREATE VIEW view_user_res_info AS
  SELECT
    `file`.`user_res_info`.`id`                                                                         AS `id`,
    `file`.`user_res_info`.`dirId`                                                                      AS `dirId`,
    `file`.`user_res_info`.`courseId`                                                                   AS `courseId`,
    `file`.`user_res_info`.`title`                                                                      AS `title`,
    `file`.`user_res_info`.`classId`                                                                    AS `classId`,
    `file`.`user_res_info`.`content`                                                                    AS `content`,
    `file`.`user_res_info`.`fileId`                                                                     AS `fileId`,
    `file`.`upload_file_info`.`name`                                                                    AS `fileName`,
    concat(convert(`file`.`file_server_info`.`serverUrl` USING utf8), `file`.`upload_file_info`.`path`) AS `fileUrl`,
    `file`.`upload_file_info`.`size`                                                                    AS `fileSize`,
    `file`.`upload_file_info`.`ext`                                                                     AS `fileExt`,
    `file`.`user_res_info`.`isPublic`                                                                   AS `isPublic`,
    `file`.`user_res_info`.`isDel`                                                                      AS `isDel`,
    `master`.`user_base_info`.`realName`                                                                AS `createUserName`,
    `file`.`user_res_info`.`createTime`                                                                 AS `createTime`,
    `file`.`user_res_info`.`updateTime`                                                                 AS `updateTime`,
    `file`.`file_server_info`.`serverUrl`                                                               AS `serverUrl`,
    `file`.`upload_file_info`.`userId`                                                                  AS `createUserId`
  FROM ((`file`.`user_res_info`
    JOIN `file`.`upload_file_info`) JOIN `master`.`user_base_info`) JOIN `file`.`file_server_info`
  WHERE ((`file`.`user_res_info`.`fileId` = `file`.`upload_file_info`.`id`) AND
         (`file`.`user_res_info`.`createUserId` = `master`.`user_base_info`.`userId`) AND
         (`file`.`file_server_info`.`id` = `file`.`upload_file_info`.`serverId`));
