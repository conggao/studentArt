CREATE VIEW view_img_text_file_info AS
  SELECT
    `imgtext`.`img_text_file_info`.`id`        AS `id`,
    `imgtext`.`img_text_file_info`.`imgTextId` AS `imgTextId`,
    `imgtext`.`img_text_file_info`.`fileId`    AS `fileId`,
    `view_upload_file_info`.`NAME`             AS `fileName`,
    `view_upload_file_info`.`url`              AS `fileUrl`,
    `view_upload_file_info`.`playTime`         AS `playTime`
  FROM (`imgtext`.`img_text_file_info`
    JOIN `file`.`view_upload_file_info`)
  WHERE (`imgtext`.`img_text_file_info`.`fileId` = `view_upload_file_info`.`id`);
