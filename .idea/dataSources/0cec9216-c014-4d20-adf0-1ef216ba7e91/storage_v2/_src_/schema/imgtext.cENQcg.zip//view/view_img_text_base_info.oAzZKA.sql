CREATE VIEW view_img_text_base_info AS
  SELECT
    `imgtext`.`img_text_base_info`.`id`             AS `id`,
    `imgtext`.`img_text_base_info`.`schoolId`       AS `schoolId`,
    `imgtext`.`img_text_base_info`.`type`           AS `type`,
    `imgtext`.`img_text_type`.`name`                AS `typeName`,
    `imgtext`.`img_text_base_info`.`title`          AS `title`,
    `imgtext`.`img_text_base_info`.`content`        AS `content`,
    `imgtext`.`img_text_base_info`.`createUserId`   AS `createUserId`,
    `imgtext`.`img_text_base_info`.`createTime`     AS `createTime`,
    `imgtext`.`img_text_base_info`.`lastUpdateTime` AS `lastUpdateTime`,
    `imgtext`.`img_text_base_info`.`praiseNum`      AS `praiseNum`,
    `imgtext`.`img_text_base_info`.`commentNum`     AS `commentNum`,
    `imgtext`.`img_text_base_info`.`isDel`          AS `isDel`,
    `master`.`user_base_info`.`userName`            AS `createUserName`,
    `master`.`user_base_info`.`realName`            AS `createUserRealName`,
    `view_upload_file_info`.`url`                   AS `createUserHeadUrl`,
    `imgtext`.`img_text_base_info`.`isCanComment`   AS `isCanComment`,
    `imgtext`.`img_text_base_info`.`isCanReceipt`   AS `isCanReceipt`
  FROM ((`imgtext`.`img_text_base_info`
    LEFT JOIN `imgtext`.`img_text_type`
      ON ((`imgtext`.`img_text_base_info`.`type` = `imgtext`.`img_text_type`.`id`))) LEFT JOIN
    (`master`.`user_base_info`
      LEFT JOIN `file`.`view_upload_file_info`
        ON ((`master`.`user_base_info`.`headPicId` = `view_upload_file_info`.`id`)))
      ON ((`imgtext`.`img_text_base_info`.`createUserId` = `master`.`user_base_info`.`userId`)));
