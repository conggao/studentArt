CREATE VIEW view_img_text_praise_info AS
  SELECT
    `imgtext`.`img_text_praise_info`.`id`           AS `id`,
    `imgtext`.`img_text_praise_info`.`imgTextId`    AS `imgTextId`,
    `imgtext`.`img_text_praise_info`.`createUserId` AS `createUserId`,
    `imgtext`.`img_text_praise_info`.`createTime`   AS `createTime`,
    `imgtext`.`img_text_praise_info`.`isDel`        AS `isDel`,
    `master`.`user_base_info`.`userName`            AS `createUserName`,
    `master`.`user_base_info`.`realName`            AS `createUserRealName`,
    `view_upload_file_info`.`url`                   AS `createUserHeadUrl`
  FROM ((`imgtext`.`img_text_praise_info`
    JOIN `master`.`user_base_info`
      ON ((`imgtext`.`img_text_praise_info`.`createUserId` = `master`.`user_base_info`.`userId`))) LEFT JOIN
    `file`.`view_upload_file_info` ON ((`master`.`user_base_info`.`headPicId` = `view_upload_file_info`.`id`)));
