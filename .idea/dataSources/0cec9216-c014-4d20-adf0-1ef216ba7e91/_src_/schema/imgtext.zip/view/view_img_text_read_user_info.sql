CREATE VIEW view_img_text_read_user_info AS
  (SELECT
     `imgtext`.`classId`   AS `classId`,
     `imgtext`.`imgTextId` AS `imgTextId`,
     `student`.`userId`    AS `studentId`
   FROM (`imgtext`.`img_text_class_info` `imgtext`
     JOIN `master`.`user_student_info` `student` ON ((`imgtext`.`classId` = `student`.`classNo`))))
  UNION (SELECT
           `classinfo`.`classNo` AS `classId`,
           `imgtext`.`id`        AS `imgTextId`,
           `student`.`userId`    AS `studentId`
         FROM ((`imgtext`.`img_text_base_info` `imgtext`
           JOIN `master`.`class_base_info` `classinfo`
             ON (((`imgtext`.`schoolId` = `classinfo`.`schoolId`) AND (`imgtext`.`type` = 4)))) JOIN
           `master`.`user_student_info` `student` ON ((`classinfo`.`classNo` = `student`.`classNo`))));
