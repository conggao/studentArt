CREATE VIEW view_class_base_info AS
  SELECT
    `class`.`id`      AS `id`,
    `class`.`gradeNo` AS `gradeNo`,
    `class`.`name`    AS `className`,
    `grade`.`name`    AS `gradeName`,
    `school`.`id`     AS `schoolId`,
    `school`.`name`   AS `schoolName`
  FROM ((`master`.`class_base_info` `class`
    JOIN `master`.`school_info` `school`) JOIN `master`.`grade_info` `grade`
      ON (((`class`.`gradeNo` = `grade`.`id`) AND (`class`.`schoolId` = `school`.`id`))));
