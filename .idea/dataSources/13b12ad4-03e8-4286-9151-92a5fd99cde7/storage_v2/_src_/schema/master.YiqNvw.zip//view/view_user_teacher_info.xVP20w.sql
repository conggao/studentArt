CREATE VIEW view_user_teacher_info AS
  SELECT
    `master`.`user_teacher_info`.`id`       AS `id`,
    `master`.`user_teacher_info`.`userId`   AS `userId`,
    `master`.`user_base_info`.`realName`    AS `realName`,
    `master`.`user_teacher_info`.`gradeNo`  AS `gradeNo`,
    `master`.`grade_number_info`.`name`     AS `gradeName`,
    `master`.`user_teacher_info`.`classNo`  AS `classNo`,
    `master`.`user_teacher_info`.`courseId` AS `courseId`,
    `master`.`course_info`.`name`           AS `courseName`
  FROM (((`master`.`user_teacher_info`
    JOIN `master`.`user_base_info`) JOIN `master`.`course_info`) JOIN `master`.`grade_number_info`)
  WHERE ((`master`.`user_teacher_info`.`userId` = `master`.`user_base_info`.`userId`) AND
         (`master`.`user_teacher_info`.`courseId` = `master`.`course_info`.`id`) AND
         (`master`.`user_teacher_info`.`gradeNo` = `master`.`grade_number_info`.`id`));

