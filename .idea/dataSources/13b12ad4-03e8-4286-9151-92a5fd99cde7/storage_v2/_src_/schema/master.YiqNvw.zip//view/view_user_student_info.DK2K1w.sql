CREATE VIEW view_user_student_info AS
  SELECT
    `master`.`user_student_info`.`userId`   AS `userId`,
    `master`.`user_base_info`.`realName`    AS `realName`,
    `master`.`user_school_info`.`schoolId`  AS `schoolId`,
    `master`.`school_info`.`name`           AS `schoolName`,
    `master`.`user_student_info`.`gradeNo`  AS `gradeNo`,
    `master`.`user_student_info`.`classNo`  AS `classNo`,
    `master`.`user_student_info`.`courseId` AS `courseId`,
    `master`.`course_info`.`name`           AS `courseName`
  FROM ((((`master`.`user_student_info`
    JOIN `master`.`user_school_info`) JOIN `master`.`school_info`) JOIN `master`.`user_base_info`) JOIN
    `master`.`course_info`)
  WHERE ((`master`.`user_student_info`.`userId` = `master`.`user_base_info`.`userId`) AND
         (`master`.`user_student_info`.`userId` = `master`.`user_school_info`.`userId`) AND
         (`master`.`user_school_info`.`schoolId` = `master`.`school_info`.`id`) AND
         (`master`.`user_student_info`.`courseId` = `master`.`course_info`.`id`));

