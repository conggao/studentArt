CREATE VIEW view_upload_file_info AS
  SELECT
    `f`.`id`                                                AS `id`,
    `f`.`name`                                              AS `NAME`,
    `f`.`size`                                              AS `size`,
    `f`.`ext`                                               AS `ext`,
    concat(convert(`s`.`serverUrl` USING utf8), `f`.`path`) AS `url`,
    `f`.`playTime`                                          AS `playTime`
  FROM (`file`.`file_server_info` `s`
    JOIN `file`.`upload_file_info` `f`)
  WHERE (`s`.`id` = `f`.`serverId`);

